package p5;
import p4.*;
// protected access modifier
public class f extends pro{
	public static void main(String[] args) {
		f obj = new f();
		obj.display();
	}

}
