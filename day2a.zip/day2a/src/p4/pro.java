package p4;

public class pro {
	protected void display() {
		System.out.println("Tns Session");
	}

}
