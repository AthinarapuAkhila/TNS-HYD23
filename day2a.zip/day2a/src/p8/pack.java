package p8;

public class pack {
	public void msg() {
		System.out.println("hello c");
	}

}

