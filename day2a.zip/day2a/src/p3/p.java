package p3;
// private access modifier
public class p {
	int a = 56;
	private void display() {
		System.out.println("Tns session");
	}

	public static void main(String[] args) {
		p obj = new p();
		System.out.println(obj.a);
		obj.display();
	}

}
