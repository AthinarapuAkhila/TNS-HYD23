package p2;
//public access modifier
import day2a.*;
public class demo {

	public static void main(String[] args) {
		D obj = new D();
		obj.display();

	}

}
