package day2a;

public class D {
	public void display()
	{
		System.out.println("Tns session");
	}

}
