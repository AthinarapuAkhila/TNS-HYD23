package user;
import p8.*;
//user defined package
import p9.*;
public class my {
	public static void main(String[] args) {
		pack obj = new pack();
		pa obj1 = new pa();
		obj.msg();
		obj1.msg();
	}

}
