package p9;

public class pa {
	public void msg() {
		System.out.println("hello D");
	}

}
