package p6;

public class dea {
	void display() {
		System.out.println("Hello world!");
	}

}
