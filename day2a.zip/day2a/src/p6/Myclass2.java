package p6;
// defeault a
public class Myclass2 {
	public static void main(String args[])
	{
		dea obj= new dea();
		obj.display();
	}

}
