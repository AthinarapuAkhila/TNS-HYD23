package day2;

public class C {
	
	int b = 25;
	static int c = 16;
	
	public static void main(String[] args) {
		
		int a = 25;
		C b1 = new C();
		System.out.println(a);
		System.out.println(b1.b);
		System.out.println(C.c);
		
	}

}





