package day2;

public class month {
	int x = 67;
	static int y = 89;
	int display() {
		return 10;
	}
	static void display1() {
		System.out.println("10");
	}

}
