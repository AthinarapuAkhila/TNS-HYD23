package day2;

public class year {
	public static void main(String[] args) {
		month obj = new month();
		System.out.println(obj.x);
		obj.display();
		System.out.println(month.y);
		month.display1();
	}

}
