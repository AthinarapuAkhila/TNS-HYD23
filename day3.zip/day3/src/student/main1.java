package student;

public class main1 {
	public static void main(String[] args) {
		student1 obj = new student1();
		obj.age = 18;
		System.out.println(obj.age);
		
	}

	

}
