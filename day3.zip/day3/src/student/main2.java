package student;

public class main2 {

	public static void main(String[] args) {
		student2 obj2 = new student2();
		obj2.setAge(20);
		System.out.println(obj2.getAge());
		
		obj2.setName("Akhila");
		System.out.println(obj2.getName());
		
	}

}
