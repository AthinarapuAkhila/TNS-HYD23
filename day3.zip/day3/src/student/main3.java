package student;

public class main3 {

	public static void main(String[] args) {
		student3 obj3 = new student3();
		obj3.setAge(20);
		obj3.setId(2);
		obj3.setName("akhila");
		System.out.println(obj3.eligible());
		
	}

}
