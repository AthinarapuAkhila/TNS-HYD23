package employee;

public class employee1 {
	private String name;
	private String address;
	public int salary;

}
