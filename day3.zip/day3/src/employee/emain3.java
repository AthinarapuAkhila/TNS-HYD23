package employee;

public class emain3 {

	public static void main(String[] args) {
		employee3 obj3 = new employee3();
		obj3.setSalary(80000);
		obj3.setAddress("HYD");
		obj3.setName("software Developer");
		System.out.println(obj3.eligibility());
	}

}
