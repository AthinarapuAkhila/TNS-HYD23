package employee;

public class emain1 {

	public static void main(String[] args) {
		employee1 obj = new employee1();
		obj.salary = 20000;
		System.out.println(obj.salary);

	}

}
