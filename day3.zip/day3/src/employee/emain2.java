package employee;

public class emain2 {

	public static void main(String[] args) {
		employee2 obj1 = new employee2();
		obj1.setSalary(40000);
		System.out.println(obj1.getSalary());
		
		obj1.setName("software developer");
		System.out.println(obj1.getName());

	}

}
