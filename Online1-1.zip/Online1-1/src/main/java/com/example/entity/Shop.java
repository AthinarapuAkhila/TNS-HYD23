package com.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Shop")
public class Shop {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "shopname")
	private String shopname;
	
	public Shop() {
		super();
	}
	
	
	
	public Shop(long id, String shopname) {
		super();
		this.id = id;
		this.shopname = shopname;
	}



	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getShopname() {
		return shopname;
	}
	public void setShopname(String shopname) {
		this.shopname = shopname;
	}



	@Override
	public String toString() {
		return "Shop [id=" + id + ", shopname=" + shopname + "]";
	}
	
	
	

}
