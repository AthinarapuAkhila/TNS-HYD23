package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.entity.Shop;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.ShopRepository;

@RestController
@RequestMapping("/api/vi")
public class ShopController {
	@Autowired
	private ShopRepository repository;
	
	@PostMapping("/shopping")
	public Shop createShop(@RequestBody Shop shop) {
		return repository.save(shop);
	}
	
	@GetMapping("/shopping")
	public List<Shop> getAllShop() {
		return repository.findAll();
	}
	
	@GetMapping("/shopping/{id}")
	public ResponseEntity<Shop> getShopById(@PathVariable Long id) {
		Shop shop = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id:" + id));
		return ResponseEntity.ok(shop);
	}

	@PutMapping("/shopping/{id}")
	public ResponseEntity<Shop> updateShop(@PathVariable Long id, @RequestBody Shop shopDetails) {
		Shop shop = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Placement not exist with id :" + id));
		
		shop.setShopname(shopDetails.getShopname());
		
		
		Shop updateshop = repository.save(shop);
		return ResponseEntity.ok(updateshop);
	}
	@DeleteMapping("/shopping/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteShop(@PathVariable Long id) {
		Shop shop = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Placement not exist with id :" + id));
		repository.delete(shop);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
		
	}

}
